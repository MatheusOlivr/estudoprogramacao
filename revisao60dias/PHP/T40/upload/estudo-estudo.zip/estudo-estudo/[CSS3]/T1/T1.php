<link rel = 'stylesheet' href = 'style.css'>
<?php
?>
<a href = 'http://localhost:8221'><button class = 'voltaraHome'>voltar a central</button></a><!--esse arquivo foi criado por um robo
-->